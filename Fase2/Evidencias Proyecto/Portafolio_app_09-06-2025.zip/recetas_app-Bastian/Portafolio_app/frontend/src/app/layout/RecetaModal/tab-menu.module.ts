import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModalRoutingModule } from './page/receta-modal-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ModalRoutingModule
  ]
})
export class ModalMenuModule { }
