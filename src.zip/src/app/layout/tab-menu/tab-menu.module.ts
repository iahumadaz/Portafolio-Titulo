import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TabRoutingModule } from './page/tab-menu-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    TabRoutingModule
  ]
})
export class TabMenuModule { }
